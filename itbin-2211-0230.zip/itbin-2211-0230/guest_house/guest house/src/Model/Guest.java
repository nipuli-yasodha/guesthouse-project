package Model;
public class Guest {
    private static String id;
    private static String name;
    private static String rooms;
    private static String phone;
    private static String date;

    // Default constructor
    public Guest() {
    }

    // Overloaded constructor
    public Guest(String id, String phone, String name, String rooms, String date) {
        Guest.id = id;
        Guest.phone = phone;
        Guest.name = name;
        Guest.rooms = rooms;
        Guest.date = date;
    }

    // Static getters and setters for each field
    public static String getId() {
        return id;
    }

    public static void setId(String id) {
        Guest.id = id;
    }

    public static String getName() {
        return name;
    }

    public static void setName(String name) {
        Guest.name = name;
    }

    public static String getRooms() {
        return rooms;
    }

    public static void setRooms(String rooms) {
        Guest.rooms = rooms;
    }

    public static String getPhone() {
        return phone;
    }

    public static void setPhone(String phone) {
        Guest.phone = phone;
    }

    public static String getDate() {
        return date;
    }

    public static void setDate(String date) {
        Guest.date = date;
    }
}
/*
    // toString method to represent the object as a string
    @Override
    public String toString() {
        return "Student{" +
                "id=" + id +
                ", phone='" + phone + '\'' +
                ", name='" + name + '\'' +
                ", rooms='" + rooms + '\'' +
                ", date='" + date + '\'' +
                '}';
    }

*/