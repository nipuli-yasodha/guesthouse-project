
package Controll;

import static Controll.Connectionz.con;
import javax.swing.JOptionPane;
import java.awt.Component;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import UI.*;

public class loginControl {

    public static String tempname;
    public static String tempun;
    public static String temppwrd;
    private static PreparedStatement pst;

    private static void setVisible(boolean b) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    private Component rootPane;
    private static ResultSet rs;
    
    public static void getloging(String id,String password){
        
        String uID,name,un,pwrd;
        LoginUI log1 =new LoginUI();
        
        if(id.equals("") || password.equals("")){
         
            JOptionPane.showMessageDialog(null,"Some fields are Empty\nPlease Enter username and passowrd");
            
        }
        else{
            try{
                con = Connectionz.getConnection();
                
                    pst = con.prepareStatement("select * from admin where username = ? and password= ?");
                    
                    pst.setString(1,id);
                    pst.setString(2, password);
                    rs = pst.executeQuery();
 
                    if(rs.next()){
                    
                        name = rs.getString("name");
                        un = rs.getString("username");
                        pwrd = rs.getString("password");
                        
                        tempname = name;
                        tempun = un;
                        temppwrd = pwrd;
                        
                        Orders_UI order = new Orders_UI(un,name,pwrd);
                        order.setVisible(true);
                        setVisible(false);
                        
                        }
                        else{
                            JOptionPane.showMessageDialog(null,"Incorrect User Name or Password");
                            log1.setVisible(true);
                        }

                
               
            }
            catch(Exception ex){
                System.out.println(""+ex);
            }
            
        }

    }
    
}
