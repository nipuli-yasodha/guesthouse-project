
package guest.house;

public class GuestHouse {


    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
