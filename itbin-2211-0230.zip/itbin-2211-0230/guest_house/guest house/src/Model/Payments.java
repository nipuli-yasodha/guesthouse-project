package Model;

public class Payments {
    private static String id;
    private static String payment;
    private static String discount;
    private static String total;

    // Default constructor
    public Payments() {
    }

    // Overloaded constructor
    public Payments(String id, String payment, String discount, String total) {
        Payments.id = id;
        Payments.payment = payment;
        Payments.discount = discount;
        Payments.total = total;
    }

    // Static getters and setters for each field
    public static String getId() {
        return id;
    }

    public static void setId(String id) {
        Payments.id = id;
    }

    public static String getPayment() {
        return payment;
    }

    public static void setPayment(String payment) {
        Payments.payment = payment;
    }

    public static String getDiscount() {
        return discount;
    }

    public static void setDiscount(String discount) {
        Payments.discount = discount;
    }

    public static String getTotal() {
        return total;
    }

    public static void setTotal(String total) {
        Payments.total = total;
    }

    // toString method to represent the object as a string
    @Override
    public String toString() {
        return "Payments{" +
                "id='" + id + '\'' +
                ", payment='" + payment + '\'' +
                ", discount='" + discount + '\'' +
                ", total='" + total + '\'' +
                '}';
    }
}
