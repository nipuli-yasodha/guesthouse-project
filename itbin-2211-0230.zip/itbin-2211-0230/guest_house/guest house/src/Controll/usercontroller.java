
package Controll;

import static Model.Guest.getId;
import static Model.Guest.*;
import javax.swing.JOptionPane;
import javax.swing.JTable;

/**
 *
 * @author Naveen viduranga
 */
public class usercontroller {
   
    public static void adddata(){
        
        if(getId().equals("") || getName().equals("")|| getRooms().equals("") || getPhone().equals("")|| getDate().equals("")){

            JOptionPane.showMessageDialog(null,"Some fields are Empty");
            
        }
        else{
            try{
                Integer.parseInt(getId());
                Integer.parseInt(getPhone());
                Integer.parseInt(getRooms());
                
                
                String[] data = {getId(),getName(),getRooms(),getPhone(),getDate()};
                DBControll.setOrderdata(data);
            }catch(NumberFormatException e){
                JOptionPane.showMessageDialog(null,"Id or phone number is not an integer");
            }

        }
    }
    
  // String id,String name,String rooms,String phone, String date
    
    public static void updateOrderdata(){
        
       // getId();
        if(getId().equals("") || getName().equals("")|| getRooms().equals("") || getPhone().equals("")|| getDate().equals("")){

            JOptionPane.showMessageDialog(null,"Some fields are Empty");
            
        }
        else{
            try{
                Integer.parseInt(getId());
                Integer.parseInt(getPhone());
                Integer.parseInt(getRooms());
                
                
                String[] data = {getId(),getName(),getRooms(),getPhone(),getDate()};
                DBControll.updatOrder(data);
            }catch(NumberFormatException e){
                JOptionPane.showMessageDialog(null,"Id or phone number is not an integer");
            }

        }
    }    
    
    
    
    
    
    
    public static void addPaymentdata(String id,String payment,String discount){
        int tot;
        if(id.equals("") || payment.equals("")|| discount.equals("")){

            JOptionPane.showMessageDialog(null,"Some fields are Empty");
            
        }
        else{
            try{
                Integer.parseInt(id);
                Integer.parseInt(payment);
                Integer.parseInt(discount);
                
                
                
                int pay = Integer.parseInt(payment);
                int dis = Integer.parseInt(discount);
                tot = pay - ( pay * dis / 100 );
                String total = Integer.toString(tot);
                
                String[] data = {id,payment,discount,total};
                DBControll.setPaymentdata(data);
            }catch(NumberFormatException e){
                JOptionPane.showMessageDialog(null,"Id  number is not an integer");
            }

        }
    }
    
    

        public static void updatePaymentdata(String id,String payment,String discount){
        int tot;
        if(id.equals("") || payment.equals("")|| discount.equals("")){

            JOptionPane.showMessageDialog(null,"Some fields are Empty");
            
        }
        else{
            try{
                Integer.parseInt(id);
                Integer.parseInt(payment);
                Integer.parseInt(discount);
                
                int pay = Integer.parseInt(payment);
                int dis = Integer.parseInt(discount);
                tot = pay - ( pay * dis / 100 );
                String total = Integer.toString(tot);
                
                String[] data = {id,payment,discount,total};
                DBControll.updatePayment(data);
            }catch(NumberFormatException e){
                JOptionPane.showMessageDialog(null,"Id or phone number is not an integer");
            }

        }
    }
    
    
    
    public static void deleteOrderdata(String id){
        DBControll.deleteguest(id);
        DBControll.deletepaymentdata(id);
    }
    
    public static void deletePayemet(String id){
        DBControll.deletepaymentdata(id);
    }
    
    public static void changepassword(String id, String newpassword, String oldpassword){
        if(DBControll.getpassword(id).equals(oldpassword) == true){
            DBControll.setpassword(id, newpassword);
        }else{
             
        }
    }
    
    public static void addEvent(String id,String date,String description){
               if(id.equals("") || date.equals("")|| description.equals("")){

            JOptionPane.showMessageDialog(null,"Some fields are Empty"); 
        }
        else{
            try{
                Integer.parseInt(id);
                
                
                String[] data = {id,date,description};
                DBControll.setEvent(data);
            }catch(NumberFormatException e){
                JOptionPane.showMessageDialog(null,"Id is not an integer");
            }

        }

    }
    
    public static void updateEvent(String id,String date,String description){
               if(id.equals("") || date.equals("")|| description.equals("")){

            JOptionPane.showMessageDialog(null,"Some fields are Empty"); 
        }
        else{
            try{
                Integer.parseInt(id);
                
                
                String[] data = {id,date,description};
                DBControll.updateEvent(data);
            }catch(NumberFormatException e){
                JOptionPane.showMessageDialog(null,"Id is not an integer");
            }

        }

    }
    
        public static void deleteEvent(String reason){
        DBControll.deleteEvent(reason);
    }
        
    

        
    
}
