
package Controll;


import static Controll.Connectionz.con;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.*;
import javax.swing.table.DefaultTableModel;
import UI.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import javax.swing.JTable;

public class DBControll {

    private static PreparedStatement pst;
    private static ResultSet rs,rs1;
    private static Object jTextField2;
    
    // Function for retrive data from student table

        public static void showOrderContents(JTable tblData){

        try {
            //get database connection
            con = Connectionz.getConnection();
         //   Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/school information management system","root","1234");
            Statement st = con.createStatement();
            String sql = "SELECT * FROM orders";
            ResultSet rs = st.executeQuery(sql);
            ResultSetMetaData rsmd = rs.getMetaData();
            DefaultTableModel model = (DefaultTableModel) tblData.getModel();
            
            
            int cols=rsmd.getColumnCount();
            String[] colName = new String[cols];
            for(int i=0;i<cols;i++){
                colName[i]=rsmd.getColumnName(i+1);
                model.setColumnIdentifiers(colName);
            }
            String uID,name,rooms,phone,date;
         //   String userid,name,email,department,position,password;
            while(rs.next()){
                
                        uID = rs.getString(1);
                        name = rs.getString(2);
                        rooms = rs.getString(3);
                        phone = rs.getString(4);
                        date = rs.getString(5);
                        String[] row = {uID,name,rooms,phone,date};
                
                model.addRow(row);    
            }
            st.close();
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(DBControll.class.getName()).log(Level.SEVERE, null, ex);
            
        }
        
        }
        
    //show teacher list function
        
    public static void showPaymentContents(JTable tblData){

        try {
            //get database connection
            con = Connectionz.getConnection();
         //   Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/school information management system","root","1234");
            Statement st = con.createStatement();
            String sql = "SELECT * FROM payments";
            ResultSet rs = st.executeQuery(sql);
            ResultSetMetaData rsmd = rs.getMetaData();
            DefaultTableModel model = (DefaultTableModel) tblData.getModel();
            
            
            int cols=rsmd.getColumnCount();
            String[] colName = new String[cols];
            for(int i=0;i<cols;i++){
                colName[i]=rsmd.getColumnName(i+1);
                model.setColumnIdentifiers(colName);
            }
            String uID,payment,discount,total;
         //   String userid,name,email,department,position,password;
            while(rs.next()){
                
                        uID = rs.getString(1);
                        payment = rs.getString(2);
                        discount = rs.getString(3);
                        total = rs.getString(4);
                        String[] row = {uID,payment,discount,total};
                
                model.addRow(row);    
            }
            st.close();
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(DBControll.class.getName()).log(Level.SEVERE, null, ex);
            
        }
        
        }
    
    //update
    
    
 public static boolean setOrderdata(String[] data) {
    boolean successful = false;
    String selectSql = "SELECT * FROM orders WHERE ID = ?";
    String insertSql = "INSERT INTO orders (ID, Name, Rooms, Phone, Date) VALUES (?, ?, ?, ?, ?)";

    try (Connection con = Connectionz.getConnection();
         PreparedStatement selectStmt = con.prepareStatement(selectSql);
         PreparedStatement insertStmt = con.prepareStatement(insertSql)) {
        
        // Set the parameters for the select statement
        selectStmt.setString(1, data[0]);
        
        try (ResultSet rs = selectStmt.executeQuery()) {
            if (rs.next()) {
                // The query returned a result, ID already exists
                JOptionPane.showMessageDialog(null, "ID already exists");
            } else {
                // Set the parameters for the insert statement
                insertStmt.setString(1, data[0]); // ID
                insertStmt.setString(2, data[1]); // Name
                insertStmt.setString(3, data[2]); // Rooms
                insertStmt.setString(4, data[3]); // Phone
                insertStmt.setString(5, data[4]); // Date
                
                int rowsAffected = insertStmt.executeUpdate();
                if (rowsAffected > 0) {
                    successful = true;
                    JOptionPane.showMessageDialog(null, "Data Entered Successfully");
                } else {
                    successful = false;
                }
            }
        }
        
    } catch (SQLException e) {
        e.printStackTrace();
    }
    
    return successful;
}
   
 /*   
        public static boolean setOrderdata(String[] data){
        
        boolean successfull = false;
        try{
            con = Connectionz.getConnection();
            Statement st = con.createStatement();
            
            String sql1 = "SELECT * FROM orders WHERE ID ='"+data[0];
            rs1 = st.executeQuery(sql1); 
            if (rs1.next()) {
              // The query returned 
               JOptionPane.showMessageDialog(null, "ID already exist");
            } else {
            
            String sql = "INSERT INTO teacher VALUES ('"+data[0]+"','"+data[1]+"','"+data[2]+"','"+data[3]+"')";
            int rs = st.executeUpdate(sql);
        
            if(rs>0){
                successfull = true;
                JOptionPane.showMessageDialog(null,"Data Entered Sucessfully ");
            }else{
                successfull = false;
            }
            st.close();
            con.close();

            }
 
        }catch(Exception e){
        }
        
        return successfull;
    }
        
        */
        
        public static boolean setPaymentdata(String[] data){
        
        boolean successfull = false;
        try{
            con = Connectionz.getConnection();
            Statement st = con.createStatement();
            
            String sql2 = "SELECT * FROM payments WHERE ID ='"+data[0]+"' ";
            rs1 = st.executeQuery(sql2); 
            if (rs1.next()) {
              // The query returned 
               JOptionPane.showMessageDialog(null, "ID already exist");
            } else {
            
            String sql = "INSERT INTO payments VALUES ('"+data[0]+"','"+data[1]+"','"+data[2]+"','"+data[3]+"')";
            int rs = st.executeUpdate(sql);
        
            if(rs>0){
                successfull = true;
                JOptionPane.showMessageDialog(null,"Data Entered Sucessfully ");
            }else{
                successfull = false;
            }
            st.close();
            con.close();

            }
 
        }catch(Exception e){
        }
        
        return successfull;
    }
  
    public static boolean updatOrder(String[] data){
        boolean successfull = false;
        try{
            con = Connectionz.getConnection();
            Statement st = con.createStatement();
            
            String sql2 = "SELECT * FROM orders WHERE ID = '"+data[0]+"' ";
            rs1 = st.executeQuery(sql2); 
            if (rs1.next()) {
              // The query returned 
            
            String sql = "UPDATE orders SET Name = '"+data[1]+"',Rooms = '"+data[2]+"',Phone = '"+data[3]+"',Date = '"+data[4]+"' WHERE ID = '"+data[0]+"'  ";
 
            int rs = st.executeUpdate(sql);
        
            if(rs>0){
                successfull = true;
                JOptionPane.showMessageDialog(null,"Data Updated Sucessfully ");
            }else{
                successfull = false;
            }
            st.close();
            con.close();

            }
 
            else {
            JOptionPane.showMessageDialog(null, "Username Not match");
            }

        }catch(Exception e){
        }
        
        return successfull;
    }


       public static boolean updatePayment(String[] data){
        boolean successfull = false;
        try{
            con = Connectionz.getConnection();
            Statement st = con.createStatement();
            
            String sql2 = "SELECT * FROM payments WHERE ID = '"+data[0]+"' ";
            rs1 = st.executeQuery(sql2); 
            if (rs1.next()) {
              // The query returned 
            
            String sql = "UPDATE payments SET Payment = '"+data[1]+"',Discount = '"+data[2]+"' ,Total = '"+data[3]+"' WHERE ID = '"+data[0]+"'  ";
 
            int rs = st.executeUpdate(sql);
        
            if(rs>0){
                successfull = true;
                JOptionPane.showMessageDialog(null,"Data Updated Sucessfully ");
            }else{
                successfull = false;
            }
            st.close();
            con.close();

            }
 
            else {
            JOptionPane.showMessageDialog(null, "Username Not match");
            }

        }catch(Exception e){
        }
        
        return successfull;

    }
    
    
    
    
    public static boolean deleteguest(String id){
        boolean successfull = false;
        try{
            con = Connectionz.getConnection();
            Statement st = con.createStatement();
            String sql = "DELETE FROM orders WHERE ID='"+id+"'";
            int rs = st.executeUpdate(sql);
        
        if(rs>0){
            successfull = true;
            JOptionPane.showMessageDialog(null,"Data Deleted");
        }else{
            successfull = false;
        }
        st.close();
        con.close();
        }catch(Exception e){ 
        }
        
        return successfull;
    }
    
    public static boolean deletepaymentdata(String id){
        boolean successfull = false;
        try{
            con = Connectionz.getConnection();
            Statement st = con.createStatement();
            String sql = "DELETE FROM payments WHERE ID='"+id+"'";
            int rs = st.executeUpdate(sql);
        
        if(rs>0){
            successfull = true;
            JOptionPane.showMessageDialog(null,"Data Deleted");
        }else{
            successfull = false;
        }
        st.close();
        con.close();
        }catch(Exception e){ 
        }
        
        return successfull;
    }
    
        public static String getpassword(String username){
        String password=null;
        try {
            //get database connection
            con = Connectionz.getConnection();
            Statement st = con.createStatement();
            String sql = "SELECT password FROM student WHERE username = '"+username+"'";
            ResultSet rs = st.executeQuery(sql);
            ResultSetMetaData rsmd = rs.getMetaData();
            
            while(rs.next()){
                password = rs.getString(1);
            }
            st.close();
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(DBControll.class.getName()).log(Level.SEVERE, null, ex);
            
        }
        return password;
    }
    
    
        public static void setpassword(String username, String  pas){
        try{
            con = Connectionz.getConnection();
            Statement st = con.createStatement();
            String sql = "UPDATE student SET password = '"+pas+"' WHERE username = '"+username+"'";
        int rs = st.executeUpdate(sql);
            JOptionPane.showMessageDialog(null,"Password Updated Sucessfully ");
        } catch (SQLException ex) {
            Logger.getLogger(DBControll.class.getName()).log(Level.SEVERE, null, ex);
            
        }
    }
        
        
    public static String tgetpassword(String username){
        String password=null;
        try {
            //get database connection
            con = Connectionz.getConnection();
            Statement st = con.createStatement();
            String sql = "SELECT password FROM teacher WHERE username = '"+username+"'";
            ResultSet rs = st.executeQuery(sql);
            ResultSetMetaData rsmd = rs.getMetaData();
            
            while(rs.next()){
                password = rs.getString(1);
            }
            st.close();
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(DBControll.class.getName()).log(Level.SEVERE, null, ex);
            
        }
        return password;
    }
    
    
        public static void tsetpassword(String username, String  pas){
        try{
            con = Connectionz.getConnection();
            Statement st = con.createStatement();
            String sql = "UPDATE teacher SET password = '"+pas+"' WHERE username = '"+username+"'";
        int rs = st.executeUpdate(sql);
            JOptionPane.showMessageDialog(null,"Password Updated Sucessfully ");
        } catch (SQLException ex) {
            Logger.getLogger(DBControll.class.getName()).log(Level.SEVERE, null, ex);
            
        }
    }    
        
        
        
        
        
        
        
        public static void changepassword(String username, String newpassword, String oldpassword,int t){
        if(t==5){
            if(DBControll.tgetpassword(username).equals(oldpassword) == true){
            DBControll.tsetpassword(username, newpassword);
            }
            else{
                JOptionPane.showMessageDialog(null,"Old password invalid");
            }
        }else if(t==0){
            if(DBControll.getpassword(username).equals(oldpassword) == true){
            DBControll.setpassword(username, newpassword);
            }
            else{
                JOptionPane.showMessageDialog(null,"Old password invalid");
            }
        }
    }
        
        
    public static boolean setEvent(String[] data){
        
        boolean successfull = false;
        try{
            con = Connectionz.getConnection();
            Statement st = con.createStatement();
            
            String sql1 = "SELECT * FROM event WHERE ID ='"+data[0]+"' ";
            rs1 = st.executeQuery(sql1); 
            if (rs1.next()) {
              // The query returned 
               JOptionPane.showMessageDialog(null, "ID already exist");
            } else {
            
            String sql = "INSERT INTO event VALUES ('"+data[0]+"','"+data[1]+"','"+data[2]+"')";
            int rs = st.executeUpdate(sql);
        
            if(rs>0){
                successfull = true;
                JOptionPane.showMessageDialog(null,"Data Entered Sucessfully ");
            }else{
                successfull = false;
            }
            st.close();
            con.close();

            }
 
        }catch(Exception e){
        }
        
        return successfull;
    }    
    
        public static boolean updateEvent(String[] data){
        boolean successfull = false;
        try{
            con = Connectionz.getConnection();
            Statement st = con.createStatement();
            
            String sql2 = "SELECT * FROM event WHERE ID = '"+data[0]+"' ";
            rs1 = st.executeQuery(sql2); 
            if (rs1.next()) {
              // The query returned 
            
            String sql = "UPDATE event SET Date = '"+data[1]+"',Description = '"+data[2]+"' WHERE ID = '"+data[0]+"'  ";
 
            int rs = st.executeUpdate(sql);
        
            if(rs>0){
                successfull = true;
                JOptionPane.showMessageDialog(null,"Data Updatedd Sucessfully ");
            }else{
                successfull = false;
            }
            st.close();
            con.close();

            }
 
            else {
            JOptionPane.showMessageDialog(null, "ID Not match");
            }

        }catch(Exception e){
        }
        
        return successfull;
    }
        
        public static boolean deleteEvent(String id){
        boolean successfull = false;
        try{
            con = Connectionz.getConnection();
            Statement st = con.createStatement();
            String sql = "DELETE FROM event WHERE ID='"+id+"'";
            int rs = st.executeUpdate(sql);
        
        if(rs>0){
            successfull = true;
            JOptionPane.showMessageDialog(null,"Data Deleted ");
        }else{
            successfull = false;
        }
        st.close();
        con.close();
        }catch(Exception e){ 
        }
        
        return successfull;
    }
        
  


        

}
